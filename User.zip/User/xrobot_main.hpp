#include "app_framework.hpp"
#include "libxr.hpp"

// Module headers
#include "AtomImuCan.hpp"
#include "BlinkLED.hpp"
#include "BMI088.hpp"
#include "BuzzerAlarm.hpp"
#include "Chassis.hpp"
#include "CMD.hpp"
#include "DMMotor.hpp"
#include "DR16.hpp"
#include "EventBinder.hpp"
#include "Gimbal.hpp"
#include "HostData.hpp"
#include "InfantryLauncher.hpp"
#include "LegVmc.hpp"
#include "MadgwickAHRS.hpp"
#include "Motor.hpp"
#include "PowerControl.hpp"
#include "Referee.hpp"
#include "RMMotor.hpp"
#include "SharedTopic.hpp"
#include "SharedTopicClient.hpp"
#include "SuperPower.hpp"
#include "VT13.hpp"
#include "Wheelleg.hpp"

static void XRobotMain(LibXR::HardwareContainer &hw) {
  using namespace LibXR;
  ApplicationManager appmgr;

  // Auto-generated module instantiations
  static BlinkLED blink_led(hw, appmgr, 250);
  static BMI088 BMI088_0(hw, appmgr, BMI088::GyroFreq::GYRO_2000HZ_BW532HZ, BMI088::AcclFreq::ACCL_1600HZ, BMI088::GyroRange::DEG_2000DPS, BMI088::AcclRange::ACCL_24G, {0.0, 0.0, 0.0, 1.0}, {0.3, 1.0, 0.05, 0.0, 0.3, 1.0, false}, "gimbal_gyro", "bmi088_accl", 45, 1024+256+128);
  static MadgwickAHRS MadgwickAHRS_0(hw, appmgr, 0.05, "gimbal_gyro", "bmi088_accl", "ahrs_quaternion", "gimbal_euler", 2048-128);

  static BuzzerAlarm BuzzerAlarm_0(hw, appmgr, 5000, 300, 300);
  static CMD cmd(hw, appmgr, CMD::Mode::CMD_OP_CTRL, "chassis_cmd", "gimbal_cmd", "launcher_cmd");
  static RMMotor motor_pit(hw, appmgr, {RMMotor::Model::MOTOR_GM6020, false, 0x20B, "can2"});
  static DMMotor motor_yaw(hw, appmgr, {DMMotor::Model::MOTOR_DM4310, false, 0x006, "can2"});
  static RMMotor motor_fric_0(hw, appmgr, {RMMotor::Model::MOTOR_M3508, true, 0x203, "can1"});
  static RMMotor motor_fric_1(hw, appmgr, {RMMotor::Model::MOTOR_M3508, false, 0x202, "can1"});
  static RMMotor motor_trig(hw, appmgr, {RMMotor::Model::MOTOR_M2006, false, 0x201, "can1"});

  static RMMotor left_wheel(hw, appmgr, {RMMotor::Model::MOTOR_M3508, false, 0x204, "can2"});
  static RMMotor right_wheel(hw, appmgr, {RMMotor::Model::MOTOR_M3508, false, 0x205, "can1"});


  static Referee Referee_0(hw,appmgr,1024, "uart_referee" ,115200,"chassis_ref","launcher_ref","sentry_ref");
 static SuperPower SuperPower_0(hw, appmgr,  "can1");
  static AtomImuCan AtomImuCan_0(hw, appmgr, {10, "can2"});
  // static DR16 dr16(hw, appmgr, cmd, 1024);
  static VT13 vt13(hw, appmgr, cmd, 1024);

 static InfantryLauncher launcher(hw, appmgr, &motor_fric_0, &motor_fric_1, &motor_trig, 1344, {1.0, 45.0, 0.1, 0.0, 0.0, 0.0, false}, {1.0, 0.4, 0.0, 0.0, 0.0, 0.0, false}, {0.8, 0.0008, 0.0, 0.0, 0.0, 0.6, false}, {0.8, 0.0008, 0.0, 0.0, 0.0, 0.6, false}, {6000.0, 36.0, 10, 10, 0.02, 0.0, 3.0, 25.0, 1.5, 0.2, 10.5}, &cmd,Referee_0);
static Wheelleg Wheelleg(hw, appmgr, cmd, Referee_0,SuperPower_0, 3072,
    {0.21, 0.21, 0.25, 0.25, 0.0}, {0.21, 0.21, 0.25, 0.25, 0.0},
    {1.0, 900.0, 10.0,  50.0, 10.0, 280.0, false},
    {1.0, 900.0, 10.0, 50.0, 10.0, 280.0, false},
     {1.0, 15.0, 0.0, 0.0, 1.0, 5.0, true},
     {1.0, 15.0, 0.0, 0.0, 1.0, 5.0, true},
    {1.0, 1000.0, 250., 50., 0.0, 250.0, false},
    {DMMotor::Model::MOTOR_DM8009, true, 1, "can2"}, {DMMotor::Model::MOTOR_DM8009, true, 2, "can2"}, {DMMotor::Model::MOTOR_DM8009, true, 4, "can1"}, {DMMotor::Model::MOTOR_DM8009, true, 3, "can1"},
    &left_wheel, &right_wheel,
    {{0.0, 0.0, 0.0, 0.0}, {0.16, 0.16},
    {120.0, 120.0}, 0.06, 2.8, {
{-0.17964, -7.9817, 3.1923, 10.308, -0.40514, -3.5636},
     {-0.66707, -24.717, 10.265, 31.813, -2.1012, -11.494},
     {-3.1043, 10.416, -5.9981, -5.8995, 2.0412, 8.0467},
     {-0.85674, 3.1335, -2.1146, -0.88721, 0.31777, 2.8097},
     {-2.6373, -67.147, 13.755, 43.568, 17.816, -22.68},
     {-0.10641, -4.5356, 0.90242, -3.8511, 3.3481, -1.9635},
     {-0.75778, -4.5324, -24.709, 22.131, -3.6925, 33.08},
     {0.067102, -1.4103, -1.2455, 3.916, -6.8455, 1.7951},
     {-20.445, 3.691, 36.239, 50.742, -41.937, -28.572},
     {-2.3591, -0.13041, 5.9707, 6.2157, -5.7519, -5.9516},
     {-0.17964, 3.1923, -7.9817, -3.5636, -0.40514, 10.308},
     {-0.66707, 10.265, -24.717, -11.494, -2.1012, 31.813},
     {3.1043, 5.9981, -10.416, -8.0467, -2.0412, 5.8995},
     {0.85674, 2.1146, -3.1335, -2.8097, -0.31777, 0.88721},
     {-0.75778, -24.709, -4.5324, 33.08, -3.6925, 22.131},
     {0.067102, -1.2455, -1.4103, 1.7951, -6.8455, 3.916},
     {-2.6373, 13.755, -67.147, -22.68, 17.816, 43.568},
     {-0.10641, 0.90242, -4.5356, -1.9635, 3.3481, -3.8511},
     {-20.445, 36.239, 3.691, -28.572, -41.937, 50.742},
     {-2.3591, 5.9707, -0.13041, -5.9516, -5.7519, 6.2157},
     {5.9595, 8.0404, -18.883, -43.456, 25.774, 21.551},
     {19.093, 24.382, -61.539, -135.92, 86.386, 69.414},
     {-3.1414, -39.347, -5.0966, 70.734, -35.46, 11.981},
     {-0.78495, -13.765, -0.61381, 23.391, -13.329, 2.3574},
     {39.872, 98.804, -24.539, -259.31, 104.41, 18.818},
     {2.6175, 13.33, -4.6438, -20.315, 4.0176, 6.4923},
     {6.4786, -38.171, -16.035, 26.561, -117.89, 66.911},
     {0.070821, 3.6979, 5.5753, -14.182, -4.719, -0.081343},
     {-5.3429, -363.68, 20.546, 350.22, 164.07, -42.766},
     {1.5164, -29.704, -4.3646, 17.849, 26.169, 3.5717},
     {5.9595, -18.883, 8.0404, 21.551, 25.774, -43.456},
     {19.093, -61.539, 24.382, 69.414, 86.386, -135.92},
     {3.1414, 5.0966, 39.347, -11.981, 35.46, -70.734},
     {0.78495, 0.61381, 13.765, -2.3574, 13.329, -23.391},
     {6.4786, -16.035, -38.171, 66.911, -117.89, 26.561},
     {0.070821, 5.5753, 3.6979, -0.081343, -4.719, -14.182},
     {39.872, -24.539, 98.804, 18.818, 104.41, -259.31},
     {2.6175, -4.6438, 13.33, 6.4923, 4.0176, -20.315},
     {-5.3429, 20.546, -363.68, -42.766, 164.07, 350.22},
     {1.5164, -4.3646, -29.704, 3.5717, 26.169, 17.849}}});


  static Gimbal gimbal(hw, appmgr, cmd, Referee_0,Wheelleg, 1536, {1.0,60.0, .0, 0.0005f, 50.0, 0.0, true}, {1.0, 2.5f, 0.0, 0.0, 0.0, 8.0, false}, {1.0,100.0, 5.0 , 0.00, 0.0, 0.0, false}, {1.0, 0.27, 0., 0.0, 0.0, 0.0, false}, &motor_pit, &motor_yaw, 4.7f, 3.7f, 1.4f, -0.08f,0.0f,0.015, 0.025,0.0f, -2.1843884 - 0.754571438,0.0f,0.0f, true);
  static HostData HostData_0(hw, appmgr, cmd, "target_euler", "chassis_data", "fire_notify");
  static SharedTopic SharedTopic_0(hw, appmgr, "usb_otg_hs_cdc", 256, {"fire_notify", "target_euler", "chassis_data"});
 static SharedTopicClient SharedTopicClient_0(hw, appmgr, "usb_otg_hs_cdc", 8, {"ahrs_quaternion"});
static EventBinder event_bind(hw, appmgr, {
// {"dr16", dr16},
 {"cmd", cmd}, {"vt13", vt13},
{"wheelleg",Wheelleg},
// {"wheelleg_src", Wheelleg},
{"launcher",launcher} },
 {
{{
// {"dr16", DR16::SwitchPos::DR16_SW_R_POS_TOP, "cmd", CMD::Mode::CMD_OP_CTRL},
// {"dr16", DR16::Key::KEY_R_PRESS, "cmd", CMD::Mode::CMD_AUTO_CTRL},
// {"dr16", DR16::Key::KEY_R_RELEASE, "cmd", CMD::Mode::CMD_OP_CTRL},
{"vt13", VT13::SwitchPos::VT13_KEY_CUSTOM_L_TOGGLE_ON, "cmd", CMD::Mode::CMD_AUTO_CTRL},
{"vt13", VT13::SwitchPos::VT13_KEY_CUSTOM_L_TOGGLE_OFF, "cmd", CMD::Mode::CMD_OP_CTRL},
{"vt13", VT13::Key::KEY_R_PRESS, "cmd", CMD::Mode::CMD_AUTO_CTRL},
{"vt13", VT13::Key::KEY_R_RELEASE, "cmd", CMD::Mode::CMD_OP_CTRL}
}},

{{
// {"dr16", DR16::SwitchPos::DR16_SW_R_POS_TOP, "launcher", InfantryLauncher::FricEvent::SET_FRICMODE_SAFE},
// {"dr16", DR16::SwitchPos::DR16_SW_R_POS_MID, "launcher", InfantryLauncher::FricEvent::SET_FRICMODE_READY},

{"vt13", VT13::SwitchPos::VT13_KEY_CUSTOM_R_TOGGLE_OFF, "launcher", InfantryLauncher::FricEvent::SET_FRICMODE_SAFE}, {"vt13", VT13::SwitchPos::VT13_KEY_CUSTOM_R_TOGGLE_ON, "launcher", InfantryLauncher::FricEvent::SET_FRICMODE_READY}}},
{{
// {"dr16", DR16::SwitchPos::DR16_SW_L_POS_TOP, "wheelleg",Wheelleg::WheellegEvent::SET_MODE_RELAX}, {"dr16", DR16::SwitchPos::DR16_SW_L_POS_MID, "wheelleg", Wheelleg::WheellegEvent::SET_MODE_RESET},{"dr16", DR16::SwitchPos::DR16_SW_L_POS_BOT, "wheelleg", Wheelleg::WheellegEvent::SET_MODE_ROTOR},
// {"dr16", DR16::Key::KEY_R, "wheelleg", Wheelleg::WheellegEvent::SET_MODE_RESET},
// {"dr16", DR16::Key::KEY_E, "wheelleg", Wheelleg::WheellegEvent::SET_MODE_STAND},
// {"dr16", DR16::Key::KEY_Q, "wheelleg", Wheelleg::WheellegEvent::SET_MODE_ROTOR},
{"vt13", VT13::SwitchPos::VT13_SW_POS_C, "wheelleg", Wheelleg::WheellegEvent::SET_MODE_RELAX},
{"vt13", VT13::SwitchPos::VT13_SW_POS_N, "wheelleg", Wheelleg::WheellegEvent::SET_MODE_RESET},
{"vt13", VT13::SwitchPos::VT13_SW_POS_S, "wheelleg", Wheelleg::WheellegEvent::SET_MODE_ROTOR},
// {"vt13", VT13::SwitchPos::VT13_KEY_PAUSE_TOGGLE_ON, "wheelleg", Wheelleg::WheellegEvent::SET_MODE_JUMP},
{"vt13", VT13::Key::KEY_R, "wheelleg", Wheelleg::WheellegEvent::SET_MODE_RESET},
{"vt13", VT13::Key::KEY_E, "wheelleg", Wheelleg::WheellegEvent::SET_MODE_STAND},
{"vt13", VT13::Key::KEY_Q, "wheelleg", Wheelleg::WheellegEvent::SET_MODE_ROTOR}
}},

});

  while (true) {
    appmgr.MonitorAll();
    Thread::Sleep(1000);
  }
}
